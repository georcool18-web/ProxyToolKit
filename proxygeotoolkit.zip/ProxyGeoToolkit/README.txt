ProxyGeoToolkit (MVP)
====================

This repository contains the source code for the MVP version of the
ProxyGeoToolkit Android application. The app is written in Kotlin and
Jetpack Compose, uses Material3 for its UI and integrates with the
Shizuku framework to perform elevated operations without requiring root
access. The project adheres to the constraints specified in the
requirements, including encrypted storage of secrets and support for
Russian and English localisations.

Key Features
------------

* **Shizuku Access:** Checks whether the Shizuku service is running and
  whether the application has been granted permission. A button on the
  main screen allows requesting permission from the user. When Shizuku
  is unavailable, the UI reflects this status.
* **Proxy Profiles:** A dedicated tab lets users create and manage
  SOCKS5/HTTP proxy profiles. Profiles consist of a name, host, port
  and optional username/password fields. Profiles are stored in memory
  in this MVP; persistent storage can be wired up via
  `EncryptedSharedPreferences` as a future improvement.
* **SIM/Region:** The SIM/Region tab allows the user to set a custom
  carrier display name and choose a system locale. Because altering
  telecom parameters is not possible without privileged access, the
  entered carrier name is stored locally and displayed back to the
  user for visual spoofing only. Locale selection uses the new
  `AppCompatDelegate` APIs available in modern versions of Android.
* **Diagnostics:** The diagnostics tab provides a “Check IP/DNS”
  button that makes an HTTPS request to the `api.ipify.org` service via
  OkHttp to display the device’s current public IP address. The
  networking code runs off the main thread and does not emit logs or
  leak any sensitive information.

Building the App
----------------

To build the release APK yourself, ensure you have a recent version of
Android Studio or the Android command‑line tools installed along with
Java 17. Then run the following from the root of the repository:

```bash
./gradlew assembleRelease
```

The resulting APK will be located in `app/build/outputs/apk/release/` and
will be named `app-release.apk`. You can install this APK onto your
device using `adb install app/build/outputs/apk/release/app-release.apk`.

Note
----

The code provided here forms a solid foundation but does not perform
system‑level modifications. Some features, such as per‑app proxy
routing or dynamic carrier name changes, require system support that
may not be available via public APIs and therefore are implemented as
UI-only in this MVP. Please review the source code and adapt as needed
for your own deployments.