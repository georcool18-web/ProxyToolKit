package com.example.proxygeotoolkit

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application class annotated for Hilt.
 * This is required when using Hilt in the project, even if
 * dependency injection is minimal. The annotation generates
 * the necessary components at compile time.
 */
@HiltAndroidApp
class ProxyGeoToolkitApplication : Application()