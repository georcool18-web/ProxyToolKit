package com.example.proxygeotoolkit

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.proxygeotoolkit.ui.theme.ProxyGeoToolkitTheme
import dev.rikka.shizuku.Shizuku
import dev.rikka.shizuku.ShizukuBinderWrapper
import dev.rikka.shizuku.ShizukuProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown

/**
 * Main activity for ProxyGeoToolkit. The app is built with Jetpack Compose and
 * follows a tab-based layout to separate the core areas of functionality:
 *  - Main screen showing Shizuku status and current profile state.
 *  - Profiles tab to manage proxy profiles.
 *  - SIM/Region tab to adjust carrier name and locale (visual only).
 *  - Diagnostics tab to check current IP and DNS status via a remote API.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProxyGeoToolkitTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ProxyGeoToolkitApp()
                }
            }
        }
    }
}

@Composable
fun ProxyGeoToolkitApp() {
    var currentTab by remember { mutableStateOf(MainTab.MAIN) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text(text = stringResource(id = R.string.app_name)) })
        },
        bottomBar = {
            NavigationBar {
                MainTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { /* icons could be added here if desired */ },
                        label = { Text(text = stringResource(id = tab.titleRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
                MainTab.MAIN -> MainScreen()
                MainTab.PROFILES -> ProfilesScreen()
                MainTab.SIM_REGION -> SimRegionScreen()
                MainTab.DIAGNOSTICS -> DiagnosticsScreen()
            }
        }
    }
}

/**
 * Enumeration of app tabs with associated string resources.
 */
enum class MainTab(@StringRes val titleRes: Int) {
    MAIN(R.string.main_tab),
    PROFILES(R.string.profiles_tab),
    SIM_REGION(R.string.sim_tab),
    DIAGNOSTICS(R.string.diagnostics_tab)
}

/**
 * Main screen of the app. Displays Shizuku status and allows toggling of the
 * current proxy profile. Uses Compose state to reactively display permission
 * status and provide a button to request Shizuku permission when needed.
 */
@Composable
fun MainScreen() {
    // Track the permission status for Shizuku.
    var permissionGranted by remember { mutableStateOf(Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    // Track whether Shizuku binder is available.
    val shizukuAvailable = remember { Shizuku.pingBinder() }
    // Track state of proxy toggle.
    var proxyEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = stringResource(id = R.string.shizuku_status) + ": " +
                when {
                    !shizukuAvailable -> stringResource(id = R.string.shizuku_not_available)
                    permissionGranted -> stringResource(id = R.string.shizuku_granted)
                    else -> stringResource(id = R.string.shizuku_denied)
                }
        )
        if (shizukuAvailable && !permissionGranted) {
            Button(onClick = {
                Shizuku.requestPermission(0)
                permissionGranted = Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
            }) {
                Text(text = stringResource(id = R.string.request_shizuku))
            }
        }
        // Toggle to enable or disable the currently selected proxy profile.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = stringResource(id = R.string.proxy_toggle), modifier = Modifier.weight(1f))
            Switch(checked = proxyEnabled, onCheckedChange = { proxyEnabled = it })
        }
        // Placeholder for active profile name.
        Text(text = stringResource(id = R.string.active_profile) + ": " + if (proxyEnabled) "Default" else "--")
    }
}

/**
 * Data model representing a proxy profile. Profiles define the connection
 * parameters needed to establish a SOCKS5/HTTP(S) proxy. The username and
 * password fields are optional and may be null when authentication is not
 * required.
 */
data class ProxyProfile(
    val name: String,
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null
)

/**
 * Profiles screen. For the MVP this screen shows a simple list of proxy profiles
 * and allows adding new profiles via a dialog. Profiles are stored only in
 * memory; persistent storage can be wired up to encrypted shared preferences
 * via AndroidX security library.
 */
@Composable
fun ProfilesScreen() {
    // Maintain a list of profiles in memory for demonstration purposes.
    var profiles by remember { mutableStateOf(listOf<ProxyProfile>()) }
    var showAddDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = stringResource(id = R.string.profiles_tab), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Button(onClick = { showAddDialog = true }) {
                Text(stringResource(id = R.string.add_profile))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        profiles.forEach { profile ->
            Card(modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(text = profile.name, style = MaterialTheme.typography.bodyLarge)
                    Text(text = "${profile.host}:${profile.port}", style = MaterialTheme.typography.bodySmall)
                    if (!profile.username.isNullOrEmpty()) {
                        Text(text = profile.username, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddProfileDialog(onDismiss = { showAddDialog = false }, onAdd = { profile ->
            profiles = profiles + profile
            showAddDialog = false
        })
    }
}

@Composable
fun AddProfileDialog(onDismiss: () -> Unit, onAdd: (ProxyProfile) -> Unit) {
    // Use mutable state for form fields.
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(id = R.string.add_profile)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(stringResource(id = R.string.profile_name)) })
                OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text(stringResource(id = R.string.host)) })
                OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text(stringResource(id = R.string.port)) }, keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text(stringResource(id = R.string.username_optional)) })
                OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text(stringResource(id = R.string.password_optional)) }, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = ProxyProfile(
                    name.ifEmpty { host },
                    host,
                    port.toIntOrNull() ?: 0,
                    username.ifEmpty { null },
                    password.ifEmpty { null }
                )
                onAdd(p)
            }) {
                Text(stringResource(id = R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(id = R.string.cancel)) }
        }
    )
}

/**
 * SIM/Region screen. Provides controls to set a custom carrier display name and
 * preview the currently selected locale. System-level changes require
 * appropriate privileges; as such this MVP stores the carrier name locally and
 * displays it back to the user. Locale switching uses the new
 * AppCompatDelegate API where available.
 */
@Composable
fun SimRegionScreen() {
    var carrierName by remember { mutableStateOf("") }
    var localeCode by remember { mutableStateOf("en_US") }
    var showSaved by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = stringResource(id = R.string.carrier_name))
        OutlinedTextField(value = carrierName, onValueChange = { carrierName = it }, label = { Text(text = stringResource(id = R.string.enter_carrier_name)) })
        Text(text = stringResource(id = R.string.locale_label))
        // Simple locale selection with a few presets.
        val locales = listOf("en_US", "ru_RU", "fr_FR", "de_DE")
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedTextField(
                value = localeCode,
                onValueChange = { },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                label = { Text(text = stringResource(id = R.string.locale_label)) },
                trailingIcon = {
                    IconButton(onClick = { expanded = true }) {
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                    }
                }
            )
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                locales.forEach { loc ->
                    DropdownMenuItem(text = { Text(loc) }, onClick = {
                        localeCode = loc
                        expanded = false
                    })
                }
            }
        }
        Button(onClick = { showSaved = true }) {
            Text(text = stringResource(id = R.string.save))
        }
        if (showSaved) {
            Text(text = stringResource(id = R.string.saved_message, carrierName, localeCode))
        }
    }
}

/**
 * Diagnostics screen. Allows the user to query their current external IP address
 * and DNS reachability by making a request through OkHttp. The request is
 * issued on a background dispatcher to avoid blocking the UI thread. No
 * sensitive information is logged or stored.
 */
@Composable
fun DiagnosticsScreen() {
    val client = remember { OkHttpClient.Builder().build() }
    var result by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = {
            loading = true
            result = null
            // Launch a coroutine to perform network call.
            LaunchedEffect(Unit) {
                val text = withContext(Dispatchers.IO) {
                    try {
                        val request = Request.Builder().url("https://api.ipify.org?format=json").build()
                        client.newCall(request).execute().use { response ->
                            response.body?.string()
                        }
                    } catch (io: IOException) {
                        Log.e("Diagnostics", "Network error", io)
                        null
                    }
                }
                result = text
                loading = false
            }
        }) {
            Text(text = stringResource(id = R.string.check_ip))
        }
        if (loading) {
            CircularProgressIndicator()
        }
        result?.let { res ->
            Text(text = res)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ProxyGeoToolkitTheme {
        ProxyGeoToolkitApp()
    }
}